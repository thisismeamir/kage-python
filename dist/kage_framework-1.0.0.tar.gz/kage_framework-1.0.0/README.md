# Kage Python Framework Documentation

## Table of Contents
1. [Overview](#overview)
2. [Installation](#installation)
3. [Quick Start](#quick-start)
4. [Core Concepts](#core-concepts)
5. [API Reference](#api-reference)
6. [Usage Examples](#usage-examples)
7. [Integration Guide](#integration-guide)
8. [Error Handling](#error-handling)
9. [Best Practices](#best-practices)
10. [Advanced Usage](#advanced-usage)

## Overview

Kage is a Python framework for building JSON schema-validated plugins with function orchestration capabilities. It enables you to:

- Validate input data against JSON schemas
- Bind functions to input parameters with automatic mapping
- Execute functions in dependency order
- Generate structured JSON output
- Build reusable plugins for server applications

**Key Benefits:**
- Type-safe plugin development
- Automatic dependency resolution
- Standardized input/output handling
- Easy integration with existing projects
- Comprehensive error reporting

## Installation

### From Source
```bash
# Clone or copy the kage.py file to your project
cp kage.py your_project/
```

### As a Package

```python
# Import the framework
from kage import core, KageError, ValidationError, ExecutionError
```

### Dependencies
- Python 3.7+
- Standard library only (no external dependencies)

## Quick Start

### 1. Define Your Data and Schema

```python
from kage import core

# Input data
input_data = {
    "user": {
        "name": "Alice",
        "age": 28,
        "email": "alice@example.com"
    },
    "settings": {
        "theme": "dark",
        "language": "en"
    }
}

# Input schema
input_schema = {
    "type": "object",
    "required": ["user"],
    "properties": {
        "user": {
            "type": "object",
            "properties": {
                "name": "string",
                "age": "integer",
                "email": "string"
            }
        },
        "settings": {
            "type": "object",
            "properties": {
                "theme": "string",
                "language": "string"
            }
        }
    }
}

# Output schema (optional)
output_schema = {
    "type": "object",
    "properties": {
        "greeting": "string",
        "user_summary": "string"
    }
}
```

### 2. Create Plugin Functions

```python
def create_greeting(name: str, theme: str) -> str:
    if theme == "dark":
        return f"🌙 Good evening, {name}!"
    return f"☀️ Hello, {name}!"

def summarize_user(name: str, age: int, email: str) -> str:
    return f"{name} is {age} years old and can be reached at {email}"
```

### 3. Configure and Execute

```python
# Initialize Kage
kage = Kage(input_data, input_schema, output_schema)

# Bind functions
kage.bind_function(
    create_greeting,
    {"name": "user.name", "theme": "settings.theme"},
    output_key="greeting"
).bind_function(
    summarize_user,
    {"name": "user.name", "age": "user.age", "email": "user.email"},
    output_key="user_summary"
)

# Execute and get results
result = kage.execute()
print(kage.to_json())
```

**Output:**
```json
{
  "greeting": "🌙 Good evening, Alice!",
  "user_summary": "Alice is 28 years old and can be reached at alice@example.com"
}
```

